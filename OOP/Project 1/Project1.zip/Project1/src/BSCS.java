import java.util.Scanner;
public class BSCS {
    
    public static void main(String[] args) 
    {   
        Scanner input=new Scanner(System.in);
        int n;
        System.out.println("Enter Number of Total Students");
        n =input.nextInt();  
        String[] Name=new String[30];
        int[] Roll=new int[30];
        int[] Marks=new int[30];
        String[] Grade=new String[30];
        for(int i=1;i<=n;i++)
        {
            System.out.println("Enter Name of " + i + " " + "Student");
            Name[i]=input.next();
            System.out.println("Enter Roll Number of " + i + " " + "Student");
            Roll[i]=input.nextInt();
            System.out.println("Enter Marks of "+ i + " " + "Student");
            Marks[i]=input.nextInt();
            if(Marks[i]>=90)
            {
                Grade[i]="A+";
            }
            
            else if(Marks[i]>=80)
            {
                Grade[i]="A";
            }        
        
            else if(Marks[i]>=70)
            {
                Grade[i]="B+";
            }
        
            else if(Marks[i]>=60)
            {
                Grade[i]="B";
            }
            
            else if(Marks[i]>=50)
            {
                Grade[i]="C";
            }
            
            else
            {
                Grade[i]="F";
            }    
        }
    System.out.println(" ");
    System.out.println("-------------------------------------");
    System.out.print("Name"+"\t"+"Roll Number"+"\t"+"Marks"+"\t"+"Grade");
    System.out.println(" ");
    System.out.println("-------------------------------------");
    for(int j=1;j<=n;j++)
        {   
         System.out.println(Name[j] + "\t" + "    " + Roll[j] + "\t" + Marks[j]+ "\t" + Grade[j]);
        }
    
    }
    
}