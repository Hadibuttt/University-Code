public class member 
{
private String name;
private String address;
private int fee;
private String status;

member()
{
name="NULL";
address="NILL";
fee=0;
status="NILL";
}


public void setname(String n)
{
    name=n;
}

public String getname()
{
        return name;
}

public void setaddress(String a)
{
    address=a;
}

public String getaddress()
{
        return address;
}

public void setfee(int f)
{
    fee=f;
}

public int getfee()
{
        return fee;
}

public void setstatus(String s)
{
    status=s;
}

public String getstatus()
{
        return status;
}

void show()
{
    System.out.println(" ");
    System.out.println("-----------------------------------------------------------------");
    System.out.print("Name"+"\t"+"Address"+"\t"+"\t"+"Fee Submitted"+"\t"+"Status");
    System.out.println(" ");
    System.out.println("-----------------------------------------------------------------");
    
    System.out.println(name+"\t"+address+"\t"+fee+"\t"+"\t"+status);

}

}