public class temporary extends member 
{
       
}
