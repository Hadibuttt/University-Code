import java.util.Scanner;
public class test 
{
public static void main(String[] args) 
{
    Scanner input=new Scanner(System.in);
    permenant p1=new permenant();
    temporary t1=new temporary();
    char ch;
    do
    {
    System.out.println("Select your Membership");
    System.out.println("1. Permenant Membership");
    System.out.println("2. Temporary Membership");
    int n;
    System.out.println("Enter Your Choice:");
    n=input.nextInt();
    switch(n) 
   {
    
    case 1:
    System.out.println("Enter your name:");
    String np;
    np=input.next();
    p1.setname(np);
    
    System.out.println("Enter your Address:");
    String ap;
    ap=input.next();
    p1.setaddress(ap);
    
    System.out.println("Enter Amount for Subscription(Rs:5000)");
    int sp;
    sp=input.nextInt();
    p1.setfee(sp);
   
    if(sp>=5000)
    {
        String s;
        s="You have been Successfully Subscribed";
        p1.setstatus(s);
    }
    else
    {
        p1.setstatus(ap);
        String s1;
        s1="Subscription Failed You Entered Insufficent Amount";
        p1.setstatus(s1);
    }
    p1.show();
    break;
  
    case 2:
    System.out.println("Enter your name:");
    String nt;
    nt=input.next();
    t1.setname(nt);
    
    System.out.println("Enter your Address:");
    String at;
    at=input.next();
    t1.setaddress(at);
    
    t1.setfee(0);
    t1.setstatus("Trial Expiry Days Remaining 90");
    t1.show();
    break;
       
    default:
    System.out.println("Invalid Choice");
    break;
   }

System.out.println("Do you want to use program again:(Y|N)");
ch=input.next().charAt(0);    
}while(ch=='Y');
System.out.println("Thank You for visting us!");    
}
}