public class permenant extends member 
{
       
}
