public class Student 
{    
    Course[] C=new Course[5];
    private int roll;
    private String name;
    private int size;
    private int total;
    private float percentage;
    private String grade;
    private int ttotal;
    
    Student()
    {
        roll=0000;
        name="xyz";
    }
    Student(String s1,int n1,int cn1)
    {
    name=s1;
    roll=n1;
    size=cn1;
    C=new Course[cn1];
    ttotal=cn1*100;
    }
public void setRoll(int r)
    {roll=r;}
 public int getRoll()
    {return roll;}
 public void setname(String n)
    {name=n;}
 public String getname()
    {return name;}
    void total(int j)
    {
    total=total+C[j].getc_marks();
    
   
        
    }
  
    void grade()
 {percentage=((float) total/ttotal)*100;
 if(percentage>=80)
 grade="A1";
  if((percentage<80)&&(percentage>=70))
 grade="A";
if((percentage<70)&&(percentage>=60))
  grade="B";
 if((percentage<60)&&(percentage>=50))
 grade="C";
if((percentage<50)&&(percentage>=40))
 grade="D";
if((percentage<40))
  grade="F";
 }
    
   void show()
   {
   
   System.out.print(roll+"\t "+name);
    for(int j=0;j<size;j++)
        {   
            
            
         C[j].show(j);
         if(j==(size-1))
         {System.out.print("\nTotal Marks: "+total+"   Percentage: "+percentage+"%  Grade: "+grade+"\n\n");
         }
         
         
        
        }
  
   
   }
    
   
   
    
    
}
