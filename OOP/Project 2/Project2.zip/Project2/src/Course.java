public class Course 
{
   private int c_code;
   private String c_name;
   private int c_marks;
   private String c_grade;

Course()
    {
        c_code=0000;
        c_name="xyz";
        c_marks=00;
        c_grade="NULL";
    }
Course(int cc,String cn,int cm,String gc)
{
c_code=cc;
c_name=cn;
c_marks=cm;
c_grade=gc;

}
    
    public void setc_code(int cc)
    {
        c_code=cc;
    }
    
    public int getc_code()
    {
        return c_code;
    }
    
    public void setc_name(String cn)
    {
        c_name=cn;
    }
    
    public String getc_name()
    {
        return c_name;
    }

    public void setc_marks(int cm)
    {
        c_marks=cm;
    }
    
    public int getc_marks()
    {
        return c_marks;
    }
    
    public void setc_grade(String gc)
    {
        c_grade=gc;
    }
    
    public String getc_grade()
    {
        return c_grade;
    }
    void show(int j)
    {if(j==0)
     System.out.print("\t\t"+c_name+"\t"+c_code+"\t"+c_marks);
     else
         System.out.print("\n\t\t\t"+c_name+"\t"+c_code+"\t"+c_marks);
    
    
    }
    
}