import java.util.Scanner;
public class Run 
{
    
    public static void main(String[] args) 
{
   Scanner input=new Scanner(System.in);
   
    int n; 
    System.out.println("Enter the Amount of Students");
    n=input.nextInt();
    Student[] S=new Student[n];
    
    int csize;
    System.out.println("Enter number of courses");
    csize=input.nextInt();
    
    int n1;
    String s1;
    String c1;
    int c2;
    int cm;
    
    for(int i=0;i<n;i++)
    {
      
        System.out.println("Enter Name of student" + " " + (i+1));
        s1=input.next();
        
        System.out.println("Enter Roll of student" + " " + (i+1));
        n1=input.nextInt();
        S[i]=new Student(s1,n1,csize);
          
        
       for(int j=0;j<csize;j++)
        {
            
        S[i].C[j]=new Course();
        System.out.println("Enter Name of Course" + " " + (j+1) + " " + "for student" + " " + (i+1));
        c1=input.next();
        S[i].C[j].setc_name(c1);
        System.out.println("Enter Course code of Course" + " " + (j+1) + " " + "for student" + " "  + (i+1));
        c2=input.nextInt();
        S[i].C[j].setc_code(c2);
        
        
        System.out.println("Enter Course marks of Course" + " " + (j+1)+ " " + "for student"  + " " + (i+1));
        cm=input.nextInt();
        S[i].C[j].setc_marks(cm);
        S[i].total(j);
        
        }   
 
    S[i].grade();
        }
    
    System.out.println(" ");
    System.out.println("-------------------------------------------------");
    System.out.print("Roll#"+"\t"+"Name   "+"\t"+"C_Name"+"\t"+"C_Code"+"\t"+"C_marks");
    System.out.println(" ");
    System.out.println("-------------------------------------------------");
    for(int k=0;k<n;k++)
    {
        
        S[k].show();
     
        
       
    }
}
}